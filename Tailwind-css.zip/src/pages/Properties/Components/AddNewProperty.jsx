import React from 'react'

export default function AddNewProperty() {
  return (
    <div>
      
    </div>
  )
}
