export const Investing = [
    {
        img:"https://placehold.co/600x400",
        title:"FLorida",
        Description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
    },
    
    {
        img:"https://placehold.co/600x400",
        title:"FLorida",
        Description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
    },
    {
        img:"https://placehold.co/600x400",
        title:"FLorida",
        Description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. "
    },

]   